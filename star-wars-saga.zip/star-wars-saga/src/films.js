import { html } from 'lit-html/lit-html.js';
import { repeat } from 'lit-html/directives/repeat.js';
import { until } from 'lit-html/directives/until.js';
import { LitElement } from 'lit-element';

export class FilmsApp extends LitElement {
  render() {
    return html`
  ${until(
      fetch('https://swapi.dev/api/films/')
        .then(res => res.json())
        .then(films => {
          return html`
         <h1>Films</h1>
         <ul>
              ${repeat(
            films.results,
            film => film.episode_id,
            film => {
              return html`<br>
                   <p>
                      Title: ${film.title},
                      ReleaseDate: ${film.release_date},
                      <a href="/starship">StarShipCount:${film.starships.length}</a> ,
                      <a href="/character">PeopleCount: ${film.characters.length}</a> 
                   </p>  
              `;
            }
          )}
         </ul>
        `;
        }),
      html`
      <span>Loading Films...</span>
    `)}
`;
  }
}

customElements.define('films-app', FilmsApp);



