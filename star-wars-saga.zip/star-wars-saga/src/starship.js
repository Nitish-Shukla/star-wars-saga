import { html } from 'lit-html/lit-html.js';
import { LitElement } from 'lit-element';

export class StarshipApp extends LitElement {
  render() {
    return html`
      <div id="startship">Hello StartShip</div>
`;
  }
}

customElements.define('starship-app', StarshipApp);



