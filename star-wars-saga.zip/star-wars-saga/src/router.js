import { Router } from '@vaadin/router';
import './character.js';
import './starship.js';
import './films.js'; // Adding the lit-app component here for better performance

const routes = [
  {
    path: '/',
    component: 'films-app',
    children: [
      {
        path: 'character',
        component: 'character-app',
        action: async () => {
          await import('./character.js');
        },
      },
      {
        path: 'starship',
        component: 'starship-app',
        action: async () => {
          await import('./starship.js');
        },
      },
    ]
  },
];

const outlet = document.getElementById('outlet');
export const router = new Router(outlet);
router.setRoutes(routes);
