import { html } from 'lit-html/lit-html.js';
import { LitElement } from 'lit-element';

export class CharacterApp extends LitElement {
  render() {
    return html`
    <div id="character">Hello Character</div>
`;
  }
}

customElements.define('character-app', CharacterApp);



